#README

To install this template you need to put it in the:

"inst/rmarkdown/templates" in the rmarkdown package folder for whichever version of R you are working with.

For more information see:
http://rmarkdown.rstudio.com/developer_document_templates.html?version=0.99.1249&mode=desktop

